package kwa.pravaah.database;

public interface AsyncResponse {

    void processFinish(Object output);

}
